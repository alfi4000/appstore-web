document.addEventListener('DOMContentLoaded', function() {
    fetch('/apps')
        .then(response => response.json())
        .then(data => {
            const appsContainer = document.getElementById('apps');
            data.forEach(app => {
                const card = document.createElement('div');
                card.className = 'col-md-4 mb-3';
                card.innerHTML = `
                    <div class="card">
                        <div class="card-body">
                            <h5 class="card-title">${app.name}</h5>
                            <p class="card-text">${app.description}</p>
                            <a href="#" class="btn btn-primary">Details</a>
                        </div>
                    </div>
                `;
                appsContainer.appendChild(card);
            });
        })
        .catch(error => console.error('Error fetching apps:', error));
});