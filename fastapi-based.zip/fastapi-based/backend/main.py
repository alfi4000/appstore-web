from flask import Flask, jsonify, send_from_directory
import os

app = Flask(__name__, static_folder='frontend')

@app.route('/')
def index():
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/apps')
def apps():
    # Example data
    app_data = [
        {"name": "App 1", "description": "Description of App 1"},
        {"name": "App 2", "description": "Description of App 2"},
        {"name": "App 3", "description": "Description of App 3"}
    ]
    return jsonify(app_data)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)