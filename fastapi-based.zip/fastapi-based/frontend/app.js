document.addEventListener('DOMContentLoaded', () => {
    fetchApps();
});

function fetchApps() {
    fetch('/api/apps/')
        .then(response => response.json())
        .then(data => {
            const appsContainer = document.getElementById('apps');
            appsContainer.innerHTML = '';
            data.forEach(app => {
                const appDiv = document.createElement('div');
                appDiv.className = 'app';
                appDiv.innerHTML = `
                    <h2>${app.name}</h2>
                    <p>Version: ${app.version}</p>
                    <p>Description: ${app.description}</p>
                `;
                appsContainer.appendChild(appDiv);
            });
        })
        .catch(error => console.error('Error:', error));
}