from fastapi import FastAPI, HTTPException
from models import App

app = FastAPI()

# In-memory "database"
apps = [
    {"id": 1, "name": "ExampleApp", "version": "1.0.0", "description": "An example app."},
]

@app.get("/apps/")
async def read_apps():
    return apps

@app.post("/apps/")
async def create_app(app: App):
    apps.append(app.dict())
    return app

@app.put("/apps/{app_id}")
async def update_app(app_id: int, updated_app: App):
    for app in apps:
        if app["id"] == app_id:
            app.update(updated_app.dict())
            return app
    raise HTTPException(status_code=404, detail="App not found")

@app.delete("/apps/{app_id}")
async def delete_app(app_id: int):
    global apps
    apps = [app for app in apps if app["id"] != app_id]
    return {"message": "App deleted"}